﻿namespace NinjaDomain.Classes
{
    public enum EquipmentType
    {
        Tool=1,
        Weapon=2,
        Outwear=3
    }
}
