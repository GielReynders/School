﻿namespace NinjaDomain.Classes
{
    public enum NinjaType
    {
        Shinobi = 1,
        Kunoichi = 2
    }
}
