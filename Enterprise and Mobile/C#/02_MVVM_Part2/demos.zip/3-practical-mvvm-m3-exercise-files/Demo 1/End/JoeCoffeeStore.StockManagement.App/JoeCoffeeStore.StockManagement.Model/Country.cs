﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JoeCoffeeStore.StockManagement.Model
{
    public enum Country
    {
        Brasil,
        Ecuador,
        Ethiopia,
        Vietnam,
        Colombia,
        Peru,
        Mexico,
        Honduras,
        India,
        Indonesia,
        Guatemala
    }
}   
