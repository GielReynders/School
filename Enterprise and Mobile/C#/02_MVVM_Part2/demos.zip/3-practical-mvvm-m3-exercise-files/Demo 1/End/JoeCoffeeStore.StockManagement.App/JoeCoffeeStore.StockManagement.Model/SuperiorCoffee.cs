﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JoeCoffeeStore.StockManagement.Model
{
    public class SuperiorCoffee: Coffee
    {
        public string ExtraDescription { get; set; }
    }
}
