﻿using JoeCoffeeStore.StockManagement.App.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JoeCoffeeStore.Tests.Mocks
{
    public class MockDialogService: IDialogService
    {
        public void CloseDetailDialog()
        {
        }

        public void ShowDetailDialog()
        {
        }
    }
}
