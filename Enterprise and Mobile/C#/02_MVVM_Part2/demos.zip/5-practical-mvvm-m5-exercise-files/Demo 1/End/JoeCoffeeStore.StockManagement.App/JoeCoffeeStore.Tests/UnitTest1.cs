﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using JoeCoffeeStore.StockManagement.App.Services;
using JoeCoffeeStore.Tests.Mocks;
using System.Collections.ObjectModel;
using JoeCoffeeStore.StockManagement.Model;
using JoeCoffeeStore.StockManagement.App.ViewModel;

namespace JoeCoffeeStore.Tests
{
    [TestClass]
    public class CoffeeOverviewViewModelTests
    {

        private ICoffeeDataService coffeeDataService;
        private IDialogService dialogService;


        [TestInitialize]
        public void Init()
        {
            coffeeDataService = new MockCoffeeDataService(new MockRepository());
            dialogService = new MockDialogService();
        }

        [TestMethod]
        public void LoadAllCoffees()
        {
            //Arrange
            ObservableCollection<Coffee> coffees = null;
            var expectedCoffees = coffeeDataService.GetAllCoffees();

            //act
            var viewModel =
                new CoffeeOverviewViewModel(this.coffeeDataService, this.dialogService);
            coffees = viewModel.Coffees;

            //assert
            CollectionAssert.AreEqual(expectedCoffees, coffees);
        }
    }
}
